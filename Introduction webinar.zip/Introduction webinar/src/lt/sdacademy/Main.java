package lt.sdacademy;

public class Main {
    public static void main(String[] args) {

        int[] array = new int[2];
        array[0] = 554;
        array[1] = 123;

        for (int i = 0; i < 2; i = i + 1) {
            if (i < 2) {
                System.out.println("Int maziau uz 2");
            }
                else if (i == 3) {
                System.out.println("Int lygus 3");
            }
                    else {
                        System.out.println("Int daugiau uz 3");
                    }
                }
            }
        }
