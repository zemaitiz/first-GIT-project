package lt.sdacademy.calculator;

import java.util.Scanner;

public class CalculatorMain {
    public static void main(String[] args) {
        Scanner numberScanner = new Scanner(System.in);
        Scanner actionScanner = new Scanner(System.in);

        boolean calculate = true;

        while (calculate) {


            System.out.println("Ivesk pirma skaiciu");
            int firstNum = numberScanner.nextInt();

            System.out.println("Ivesk antra skaiciu");
            int secondNum = numberScanner.nextInt();

            System.out.println("Koki veiksma norite atlikti: + - * /");
            String action = actionScanner.nextLine();


            switch (action) {
                case ("+"): {
                    System.out.println(firstNum + secondNum);
                    break;
                }
                case ("-"): {
                    System.out.println(firstNum - secondNum);
                    break;
                }
                case ("*"): {
                    System.out.println(firstNum * secondNum);
                    break;
                }
                case ("/"): {
                    System.out.println(firstNum / secondNum);
                    break;
                }
            }
            System.out.println("Ar norite skaiciuoti toliau? TAIP : NE");
            String answer = actionScanner.nextLine();

            if (answer.equals("NE") || answer.toLowerCase().equals("ne")) {
                calculate=false;
            }
        }


        /*if (action.equals("+")) {
                System.out.println(firstNum + secondNum);
            }

            else if (action.equals("-")) {
                System.out.println(firstNum - secondNum);
            }
            else if (action.equals( "*")) {
                System.out.println(firstNum * secondNum);
            }
            else if (action.equals( "/")) {
                System.out.println(firstNum / secondNum);
            }
            else {
                System.out.println("Nezinomas veiksmas");
            }*/
    }
}
