package lt.sdacademy.person;

public class Person {
    String name;
    int age;
    double tall;

    public Person(String n, int a, double t) {
        name = n;
        age = a;
        tall = t;
    }
}
